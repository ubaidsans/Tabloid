<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tabloid Jubi | Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- masukin style ke view -->
    <?php $this->load->view('style/css.php'); ?>
</head>

<body class="skin-black">
    <!-- header logo: style can be found in header.less -->

    <?php $this->load->view('v_header.php'); ?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="left-side sidebar-offcanvas">                
            <!-- sidebar: style can be found in sidebar.less -->
            <?php 
            $data['menuSelected'] = 'menu_home';
            $this->load->view('v_left_menu.php', $data); 
            ?>
        </aside>

        <!-- Right side column. Contains the navbar and content of the page -->
        <aside class="right-side">                
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    <i class="fa fa-dashboard" style="margin-right: 10px"></i>Dashboard
                    <small>Halaman awal</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url(); ?>beranda"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active">Dashboard</li>
                </ol>
            </section>

            
        </aside><!-- /.right-side -->
</div><!-- ./wrapper -->   
<?php $this->load->view('v_footer');?>
<?php $this->load->view('style/js.php'); ?>
</body>
</html>
