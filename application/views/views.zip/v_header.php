<body class="skin-black">
<header class="header">
    <a href="<?php echo base_url(); ?>" class="logo">
        <!-- Add the class icon to your logo image or logo icon to add the margining -->
        Jubi Tabloid
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color:#E9E9E9" role="navigation">
        <!-- Sidebar toggle button-->
        <!-- <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a> -->
        <div class="navbar-right">
            <ul class="nav navbar-nav">
                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="<?php echo base_url(); ?>login/c_sign_out">
                        <i class="fa fa-sign-out"></i>Keluar
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</header>