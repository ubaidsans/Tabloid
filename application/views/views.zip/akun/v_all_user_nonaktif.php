<dl class="dl-horizontal">
    <div class="row">
        <div class="col-xs-12">                            
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Data Akun <span class="label label-danger" style="font-size:12px; padding-top:4px; padding-bottom:4px">Non Aktif</span></h3>                                    
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                    <table id="tabel_3" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Id</th>
                                <th>Foto</th>
                                <th>Nama Lengkap</th>
                                <th width="250px">Alamat Lengkap</th>
                                <th>No.Telepon</th>
                                <th width="50px">Kelas</th>
                                <th width="50px">Status</th>
                                <th width="105px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php  
                            $i = 1;
                            foreach ($biodata->result() as $row) {
                                if ($row->status == 'Non Aktif') {
                        ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td>
                                    <?php
                                        if ($row->id_user < 10) {
                                            echo "M14-00".$row->id_user;
                                        }
                                        else {
                                            echo "M14-0".$$row->id_user;
                                        }
                                     ?>
                                </td>
                                <td><img src="<?php echo base_url(); ?>assets/img/avatar/<?php echo $row->foto; ?>" width="40px"></td>
                                <td><?php echo $row->nama_lengkap; ?></td>
                                <td><?php echo $row->alamat.", ".$row->kota.", ".$row->propinsi; ?></td>
                                <td><?php echo $row->no_telepon; ?></td>
                                <td>
                                    <a href="javascript:$('#myModal .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_kelas/<?php echo $row->id_user; ?>',function(e){$('#myModal').modal('show');});">
                                        <span class="label label-default" style="font-size:12px">
                                        <?php
                                            if ($row->id_kategori == 0) {
                                                echo 'Pilih Kelas';
                                            } 
                                            else {
                                                echo substr($row->nama_kategori,6); 
                                            }
                                            
                                        ?>
                                        </span>
                                    </a>
                                </td>
                                <td>
                                    <?php 
                                        if ($row->status == 'Aktif') {
                                    ?>
                                        <a href="<?php echo base_url(); ?>akun/c_m_akun/c_m_edit_status/<?php echo $row->id_user; ?>">
                                            <span class="label label-success" style="padding-left:19px; padding-right:19px; font-size:12px">Aktif</span>
                                        </a>
                                    <?php 
                                        }
                                        else {
                                    ?>
                                        <a href="<?php echo base_url(); ?>akun/c_m_akun/c_m_edit_status/<?php echo $row->id_user; ?>">
                                            <span class="label label-danger" style="font-size:12px">Non Aktif</span>
                                        </a>
                                    <?php 
                                        }
                                    ?>                                    
                                </td>
                                <td>
                                    <a class="btn btn-success btn-sm" href="<?php echo base_url(); ?>akun/c_m_akun/c_m_detail_akun/<?php echo $row->id_user; ?>"><i class="fa fa-user" title="Lihat"></i></a>
                                    <a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>akun/c_m_akun/c_m_edit_akun/mv/<?php echo $row->id_user; ?>"><i class="fa fa-edit" title="Edit"></i></a>
                                    <a class="btn btn-danger btn-sm" href="<?php echo base_url(); ?>akun/c_m_akun/c_m_hapus_akun/<?php echo $row->id_user; ?>"><i class="fa fa-trash-o" title="Hapus"></i></a>
                                </td>
                            </tr>
                        <?php
                                $i++;
                                }
                            }
                        ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Id</th>
                                <th>Foto</th>
                                <th>Nama Lengkap</th>
                                <th>Alamat Lengkap</th>
                                <th>No.Telepon</th>
                                <th>Kelas</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                    <a href="javascript:$('#myModal .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_add_akun',function(e){$('#myModal').modal('show');});"><button class="btn btn-primary">Tambah Akun</button></a>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
</dl>