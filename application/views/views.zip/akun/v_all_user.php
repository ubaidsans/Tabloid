<dl class="dl-horizontal">
    <div class="row">
        <div class="col-xs-12">                            
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Data Akun <span class="label label-primary" style="font-size:12px; padding-top:4px; padding-bottom:4px">Semua Tamu</span></h3>                                    
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                    <table id="tabel_1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">No.</th>
                                <th width="5%">Foto</th>
                                <th width="28%">Nama Lengkap</th>
                                <th width="30%">Alamat Lengkap</th>
                                <th width="10%">No.Telepon</th>
                                <th width="10%">Status</th>
                                <th width="12%"></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php  
                            $i = 1;
                            foreach ($biodata->result() as $row) {
                        ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><img src="<?php echo base_url(); ?>assets/img/avatar/<?php echo $row->foto; ?>" width="40px"></td>
                                <td><?php echo $row->nama_lengkap; ?></td>
                                <td><?php echo $row->alamat.", ".$row->kota.", ".$row->propinsi; ?></td>
                                <td><?php echo $row->no_telepon; ?></td>
                                <td>
                                    <?php 
                                        if ($row->status == 'Aktif') {
                                    ?>
                                        <a href="<?php echo base_url(); ?>akun/c_m_akun/c_m_edit_status/<?php echo $row->id_user; ?>">
                                            <span class="label label-success" style="padding-left:19px; padding-right:19px; font-size:12px">Aktif</span>
                                        </a>
                                    <?php 
                                        }
                                        else {
                                    ?>
                                        <a href="<?php echo base_url(); ?>akun/c_m_akun/c_m_edit_status/<?php echo $row->id_user; ?>">
                                            <span class="label label-danger" style="font-size:12px">Non Aktif</span>
                                        </a>
                                    <?php 
                                        }
                                    ?>                                    
                                </td>
                                <td>
                                    <a class="btn btn-success btn-sm" href="javascript:$('#myModal3 .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_detail_akun/<?php echo $row->id_user; ?>',function(e){$('#myModal3').modal('show');});"><i class="fa fa-search" title="Lihat"></i></a>
                                    <a class="btn btn-info btn-sm" href="javascript:$('#myModal .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_edit_akun/<?php echo $row->id_user; ?>',function(e){$('#myModal').modal('show');});"><i class="fa fa-edit" title="Edit"></i></a>
                                    <a class="btn btn-danger btn-sm" href="javascript:$('#myModal2 .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_hapus_akun/<?php echo $row->id_user; ?>',function(e){$('#myModal2').modal('show');});"><i class="fa fa-trash-o" title="Hapus"></i></a>
                                </td>
                            </tr>
                        <?php
                                $i++;
                            }
                        ?>
                        </tbody>
                    </table>
                    <a href="javascript:$('#myModal .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_add_akun',function(e){$('#myModal').modal('show');});"><button class="btn btn-primary">Tambah Akun</button></a>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
</dl>