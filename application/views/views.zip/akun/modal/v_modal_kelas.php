<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-edit" style="margin-right: 10px"></i>Pilih Kelas</h4>
    </div>  

    <div class="modal-body">
        <div class="box-body">      
            <div class="box-body">
                <?php echo form_open_multipart('akun/c_m_akun/c_m_proses_kelas', array('id' => 'pilih_kelas'));?>
                <div class="box-body">
                    <div class="row">
                        <dl class="dl-horizontal">
                            <dt><label>Pilih Kelas</label></dt>
                            <dd>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-sitemap" style="width: 15px"></i></span>
                                        <input type="hidden" name="id_user" class="form-control" value="<?php echo $id; ?>">
                                        <select class="form-control" name="kategori" required>
                                            <option value="0">Pilih Kelas</option>
                                        <?php 
                                            foreach ($kelas->result() as $row) {
                                                if ($row->status_kategori == 'Aktif') {
                                        ?>
                                            <option value="<?php echo $row->id_kategori; ?>"><?php echo $row->nama_kategori; ?></option>

                                        <?php
                                                }
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                            </dd>
                        </dl>
                            
                    </div>
                    <div class="modal-footer" style="margin-bottom:-20px">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-warning">Reset</button>
                    </div>
                </div>
                <?php echo form_close();?>
            </div>                    
        </div>
    </div>
</body>
</html>
