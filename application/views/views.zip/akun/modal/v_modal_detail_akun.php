<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-search" style="margin-right: 10px"></i>Detail Pelanggan / Tamu</h4>
    </div>  
    <div class="modal-body" style="padding:0px">
        <div class="row">
            <div class="col-md-12">
                <?php 
                    foreach ($detail->result() as $row) {
                ?>
                    <dl class="dl-horizontal">
                        <div class="row" style="margin-top:10px">
                            <div class="col-md-4" style="margin-left:15px">
                                <img src="<?php echo base_url(); ?>/assets/img/avatar/<?php echo $row->foto; ?>" class="col-md-9 remove_exc_left img-circle">
                            </div>
                            <div class="col-md-8" style="margin-left:-120px">
                                <dt>Username<i class="fa fa-user-md" style="margin-left:10px"></i></dt>
                                <dd><code><?php echo $row->username; ?></code></dd>
                                <dt>Email<i class="fa fa-envelope-o" style="margin-left:10px"></i></dt>
                                <dd><code><?php echo $row->email; ?></code></dd>
                                <dt>Password<i class="fa fa-key" style="margin-left:10px"></i></dt>
                                <dd><code><?php echo md5($row->password); ?></code></dd>
                                <dt>Tgl Join<i class="fa fa-calendar" style="margin-left:10px"></i></dt>
                                <dd>
                                    <code>
                                        <?php 
                                        $tgl = $row->tgl_join;
                                        $convert_tgl = strtotime($tgl);
                                        $tgl = date('M d,Y', $convert_tgl);
                                        echo $tgl; 
                                        ?>
                                    </code>
                                </dd>
                                <dt>Level<i class="fa fa-cogs" style="margin-left:10px"></i></dt>
                                <dd><code><?php echo $row->otoritas; ?></code></dd>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <dt>Nama Lengkap<i class="fa fa-bookmark-o" style="margin-left:10px"></i></dt>
                            <dd><?php echo $row->nama_lengkap; ?></dd>
                            <?php 
                            $tgl = $row->tanggal_lahir;
                            $convert_tgl = strtotime($tgl);
                            $tgl = date('M d,Y', $convert_tgl);
                            ?>
                            <dt>Tmp, Tgl Lahir<i class="fa fa-calendar" style="margin-left:10px"></i></dt>
                            <dd><?php echo $row->tempat_lahir." | ".$tgl; ?></dd>
                            <dt>Gender<i class="fa <?php if($row->gender == 'Perempuan'){ echo 'fa-female';} else{ echo 'fa-male';}?>" style="margin-left:10px"></i></dt>
                            <dd><?php echo $row->gender; ?></dd>
                            <dt>Alamat<i class="fa fa-home" style="margin-left:10px"></i></dt>
                            <dd><?php echo $row->alamat; ?></dd>
                            <dd><?php echo $row->kota.", ".$row->propinsi; ?></dd>
                            <dd><?php echo $row->kode_pos; ?></dd>
                            <dt>Kontak<i class="fa fa-phone-square" style="margin-left:10px"></i></dt>
                            <dd><?php echo $row->no_telepon." (rumah)"; ?></dd>
                            <dd><?php echo $row->no_hp." (hp)"; ?></dd>
                        </div>
                    </dl>
                <?php
                    }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
