<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h4 class="modal-title" id="myModalLabel"><i class="fa fa-trash-o" style="margin-right:5px"></i>Hapus Pelanggan / Tamu</h4>
	</div>  
	<div class="modal-body">
		<code><?php echo $this->session->userdata('nick');?></code>, anda yakin ingin menghapus data ini?
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times-circle" style="margin-right:5px"></i>Tidak</button>
		<a href="<?php echo base_url(); ?>akun/c_m_akun/c_proses_hapus_akun/<?php echo $id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check-circle" style="margin-right:5px"></i>Yakin</button></a>
	</div>
</body>
</html>
