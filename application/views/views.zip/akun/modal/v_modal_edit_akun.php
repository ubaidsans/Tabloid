<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-edit" style="margin-right: 10px"></i>Edit Pelanggan / Tamu</h4>
    </div>  
    <div class="modal-body">
        <?php 
        echo form_open_multipart('akun/c_m_akun/c_m_proses_edit');
        foreach ($edit->result() as $row) {
            ?>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <input type="hidden" name="id_user" class="form-control" value="<?php echo $row->id_user; ?>">
                            <div class="col-md-6 enter">
                                <label>Username</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user" style="width: 15px"></i></span>
                                    <input type="text" name="username" class="form-control" placeholder="username" value="<?php echo $row->username; ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-key" style="width: 15px"></i></span>
                                    <input type="text" name="password" class="form-control" placeholder="password" value="<?php echo md5($row->password); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Email</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-envelope" style="width: 15px"></i></span>
                                    <input type="email" name="email" class="form-control" placeholder="email" value="<?php echo $row->email; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Hak Akses</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-sitemap" style="width: 15px"></i></span>
                                    <select class="form-control" name="otoritas" required>
                                        <option value="<?php echo $row->id_otoritas; ?>" selected><?php echo $row->otoritas; ?></option>
                                        <?php 
                                        if ($row->id_otoritas == 0) {
                                            ?>
                                            <option value="1" disabled>Super Admin</option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Tanggal Join</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-calendar" style="width: 15px"></i></span>
                                    <input type="date" name="tgl_join" class="form-control" placeholder="tanggal join" value="<?php echo $row->tgl_join; ?>" disabled>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 enter">
                                <label>Nama Lengkap</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-book" style="width: 15px"></i></span>
                                    <input type="text" name="nama_lengkap" class="form-control" placeholder="nama lengkap" value="<?php echo $row->nama_lengkap; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Gender</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-users" style="width: 15px"></i></span>
                                    <select class="form-control" name="gender" required>
                                        <option value="<?php echo $row->gender; ?>"><?php echo $row->gender; ?></option>
                                        <?php 
                                        if ($row->gender == 'Perempuan') {
                                            ?>
                                            <option value="Laki - Laki">Laki - Laki</option>
                                            <?php
                                        }
                                        else {
                                            ?>
                                            <option value="Perempuan">Perempuan</option>
                                            <?php 
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Kontak</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-phone" style="width: 15px"></i></span>
                                    <input type="text" name="telepon" class="form-control" placeholder="nomer telepon" value="<?php echo $row->no_telepon; ?>" required>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-mobile-phone" style="width: 15px"></i></span>
                                    <input type="text" name="hp" class="form-control" placeholder="nomer handphone" value="<?php echo $row->no_hp; ?>">
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>TTL</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-home" style="width: 15px"></i></span>
                                    <input type="text" name="tempat_lahir" class="form-control" placeholder="tempat lahir" value="<?php echo $row->tempat_lahir; ?>" required>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-calendar" style="width: 15px"></i></span>
                                    <input type="date" name="tgl_lahir" class="form-control" placeholder="tanggal lahir" value="<?php echo $row->tanggal_lahir; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Alamat</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-road" style="width: 15px"></i></span>
                                    <input type="text" name="alamat" class="form-control" placeholder="alamat lengkap" value="<?php echo $row->alamat; ?>" required>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-home" style="width: 15px"></i></span>
                                    <input type="text" name="kota" class="form-control" placeholder="kota lengkap" value="<?php echo $row->kota; ?>" required>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-globe" style="width: 15px"></i></span>
                                    <input type="text" name="propinsi" class="form-control" placeholder="propinsi lengkap" value="<?php echo $row->propinsi; ?>" required>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-briefcase" style="width: 15px"></i></span>
                                    <input type="text" name="kode_pos" class="form-control" placeholder="kode pos alamat" value="<?php echo $row->kode_pos; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Foto / Avatar</label>
                                <div class="input-group">
                                    <div class="col-md-5">
                                        <div class="row">
                                            <div class="col-md-12" style="margin:0 0 10px;">
                                                <img src="<?php echo base_url(); ?>assets/img/avatar/<?php echo $row->foto; ?>" class=" col-md-12 remove_exc_left">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <input type="file" name="userfile">     
                                        <p class="help-block">Upload foto / avatar akun.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 enter">
                                <label>Status</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-undo" style="width: 15px"></i></span>
                                    <select class="form-control" name="status" required>
                                        <option value="<?php echo $row->status; ?>"><?php echo $row->status; ?></option>
                                        <?php 
                                        if ($row->status == 'Aktif') {
                                            ?>
                                            <option value="Non Aktif">Non Aktif</option>
                                            <?php
                                        }
                                        else {
                                            ?>
                                            <option value="Aktif">Aktif</option>
                                            <?php 
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="reset" class="btn btn-warning">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
}
echo form_close();
?>
</div>
</body>
</html>
