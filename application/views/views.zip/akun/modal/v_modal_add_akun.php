<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"> <i class="fa fa-plus-square" style="margin-right: 10px"></i>Tambah Pelanggan / Tamu</h4>
    </div>  
    <div class="modal-body">
        <?php echo form_open_multipart('akun/c_m_akun/c_m_proses_add');?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6 enter">
                            <label>Username</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user" style="width: 15px"></i></span>
                                <input type="text" name="username" class="form-control" placeholder="username" required>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Password</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-key" style="width: 15px"></i></span>
                                <input type="password" name="password" class="form-control" placeholder="password" required>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Email</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-envelope" style="width: 15px"></i></span>
                                <input type="email" name="email" class="form-control" placeholder="email" required>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Hak Akses</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-sitemap" style="width: 15px"></i></span>
                                <select class="form-control" name="otoritas" required>
                                    <option value="2" disabled>Super Admin</option>
                                    <option value="1" selected>Member</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Tanggal Join</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-calendar" style="width: 15px"></i></span>
                                <input type="date" name="tgl_join" class="form-control" placeholder="tanggal join" required>
                            </div>
                        </div>
                    </div>
                    <div>
                        <hr>
                    </div>
                    <div class="row">
                        <div class="col-md-6 enter">
                            <label>Nama Lengkap</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-book" style="width: 15px"></i></span>
                                <input type="text" name="nama_lengkap" class="form-control" placeholder="nama lengkap" required>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Gender</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-users" style="width: 15px"></i></span>
                                <select class="form-control" name="gender" required>
                                    <option value="-" disabled>Pilih</option>
                                    <option value="Laki - Laki">Laki - Laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Kontak</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone" style="width: 15px"></i></span>
                                <input type="text" name="telepon" class="form-control" placeholder="nomer telepon" required>
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-mobile-phone" style="width: 15px"></i></span>
                                <input type="text" name="hp" class="form-control" placeholder="nomer handphone">
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>TTL</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-home" style="width: 15px"></i></span>
                                <input type="text" name="tempat_lahir" class="form-control" placeholder="tempat lahir" required>
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-calendar" style="width: 15px"></i></span>
                                <input type="date" name="tgl_lahir" class="form-control" placeholder="tanggal lahir" required>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Alamat</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-road" style="width: 15px"></i></span>
                                <input type="text" name="alamat" class="form-control" placeholder="alamat lengkap" required>
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-home" style="width: 15px"></i></span>
                                <input type="text" name="kota" class="form-control" placeholder="kota lengkap" required>
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-globe" style="width: 15px"></i></span>
                                <input type="text" name="propinsi" class="form-control" placeholder="propinsi lengkap" required>
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-briefcase" style="width: 15px"></i></span>
                                <input type="text" name="kode_pos" class="form-control" placeholder="kode pos alamat" required>
                            </div>
                        </div>
                        <div class="col-md-6 enter">
                            <label>Foto / Avatar</label>
                            <div class="input-group">
                                <div class="col-md-12">
                                    <input type="file" name="userfile">     
                                    <p class="help-block">Upload foto / avatar akun.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Tambahkan</button>
                        <button type="reset" class="btn btn-warning">Reset</button>
                    </div>
                </div>
            </div>
        </div>
        <?php echo form_close();?>
    </div>
</body>
</html>
