<dl class="dl-horizontal">
    <div class="row">   
    <?php 
        foreach ($detail->result() as $row) {
    ?>
        <div class="col-md-2">
            <img src="<?php echo base_url(); ?>/assets/img/avatar/<?php echo $row->foto; ?>" class="col-md-12 remove_exc_left" >
        </div>                  
        <div class="col-md-10" style="margin-left:-40px">
            <ul class="timeline">
                 <li style="margin-bottom:6px">
                    <i class="fa fa-book bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Nama Lengkap</b> : <?php echo $row->nama_lengkap; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-smile-o bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Gender</b> : <?php echo $row->gender; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-home bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Tmp, Tgl Lahir</b> : <?php echo $row->tempat_lahir; ?> |
                            <?php 
                                $tgl = $row->tanggal_lahir;
                                $convert_tgl = strtotime($tgl);
                                $tgl = date('M d, Y', $convert_tgl);
                                echo $tgl;
                            ?>
                        </p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-road bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Alamat Lengkap</b> : <?php echo $row->alamat; ?>, <?php echo $row->kota; ?>, <?php echo $row->propinsi; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-foursquare bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Kode Pos</b> : <?php echo $row->kode_pos; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-phone bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Telepon / Hp</b> : <?php echo $row->no_telepon; ?> | <?php echo $row->no_hp; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-times-circle bg-blue"></i>
                </li>
            </ul>
        </div>
        <?php
            }
        ?>
    </div>
</dl>