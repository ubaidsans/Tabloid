<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hotel Apps | Manajemen Pengguna</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- masukin style ke view -->
    <?php $this->load->view('style/css.php'); ?>
</head>


<!-- header logo: style can be found in header.less -->

<?php $this->load->view('v_header.php'); ?>

<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">                
        <!-- sidebar: style can be found in sidebar.less -->
        <?php 
        $data['menuSelected'] = 'menu_akun';
        $this->load->view('v_left_menu.php', $data); 
        ?>
        <!-- /.sidebar -->
    </aside>

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">                
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-users" style="margin-right: 10px"></i>Data Tamu Hotel
                <small>Mengatur dan Mengelola Pengguna / Tamu</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>beranda/c_beranda"><i class="fa fa-dashboard"></i>Home</a></li>
                <li><a herf="">Manajemen Tamu</a></li>
                <li class="active">Data Tamu Hotel</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <?php
            $cek = $this->session->userdata('cek');
            if ($cek == 'sukses_update') {
                ?>
                <div class="row">
                    <script type="text/javascript">
                        window.setTimeout(function() { $("#notif").alert('close'); }, 2000);                        
                    </script>
                    <div id="notif" class="alert alert-success" style="margin-right:15px">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Update</strong> berhasil!
                    </div>
                </div>
                <?php
                $this->session->unset_userdata('cek');
            }
            else if ($cek == 'sukses_tambah') {
                ?>
                <div class="row">
                    <script type="text/javascript">
                        window.setTimeout(function() { $("#notif").alert('close'); }, 2000);                        
                    </script>
                    <div id="notif" class="alert alert-success" style="margin-right:15px">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Tambah</strong> berhasil!
                    </div>
                </div>
                <?php
                $this->session->unset_userdata('cek');
            }
            else if ($cek == 'sukses_hapus') {
                ?>
                <div class="row">
                    <script type="text/javascript">
                        window.setTimeout(function() { $("#notif").alert('close'); }, 2000);                        
                    </script>
                    <div id="notif" class="alert alert-success" style="margin-right:15px">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Hapus</strong> berhasil!
                    </div>
                </div>
                <?php
                $this->session->unset_userdata('cek');
            }
            else if ($cek == 'gagal_tambah') {
                ?>
                <div class="row">
                    <script type="text/javascript">
                        window.setTimeout(function() { $("#notif").alert('close'); }, 2000);                      
                    </script>

                    <div id="notif" class="alert alert-danger" style="margin-right:15px">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <strong>Tambah</strong> gagal! <strong>Username</strong> telah digunakan!
                    </div>
                </div>
                <?php
                $this->session->unset_userdata('cek');
            }
            ?>
            <div class="row">
                <div class="col-md-12">
                    <?php $this->load->view('akun/v_all_user'); ?>
                </div>
            </div>
        </section><!-- /.content -->
    </aside><!-- /.right-side -->
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:800px">
            <div class="modal-content" >            

            </div>
        </div>
    </div>
    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:450px">
            <div class="modal-content" >            

            </div>
        </div>
    </div>
    <div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:600px">
            <div class="modal-content" >            

            </div>
        </div>
    </div>
</div><!-- ./wrapper -->
<?php $this->load->view('v_footer');?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="<?php echo base_url(); ?>assets/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/js/AdminLTE/app.js" type="text/javascript"></script>
<!-- page script -->
<script type="text/javascript">
    $(function() {
        $("#tabel_1").dataTable({
            bSort:false
        });
    });
</script>
</body>
</html>