<dl class="dl-horizontal">
    <div class="row">   
    <?php 
        foreach ($detail->result() as $row) {
    ?>                     
        <div class="col-md-12">
            <ul class="timeline">
                <li style="margin-bottom:6px">
                    <i class="fa fa-credit-card bg-blue"></i>
                    <div class="timeline-item">
                        <h3 class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>ID Anggota</b> : 
                        <?php
                            if ($row->id_user < 10) {
                                echo "M14-00".$row->id_user;
                            }
                            else {
                                echo "M14-0".$$row->id_user;
                            }
                        ?> | <?php echo $row->otoritas; ?></h3>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-user bg-blue"></i>
                    <div class="timeline-item">
                        <h3 class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Username</b> : <?php echo $row->username; ?></h3>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-key bg-blue"></i>
                    <div class="timeline-item">
                        <h3 class="timeline-header no-border" style="font-size:14px"><span class="label_tag">
                            <b>Password</b> : <?php echo md5($row->password); ?>
                        </h3>
                    </div>
                </li>
                 <li style="margin-bottom:6px">
                    <i class="fa fa-envelope-o bg-blue"></i>
                    <div class="timeline-item">
                        <h3 class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Email</b> : <?php echo $row->email; ?></h3>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-calendar bg-blue"></i>
                    <div class="timeline-item">
                        <h3 class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Tgl Gabung</b> : 
                            <?php 
                                $tgl = $row->tgl_join;
                                $convert_tgl = strtotime($tgl);
                                $tgl = date('M d, Y', $convert_tgl);
                                echo $tgl; 
                            ?>
                        </h3>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-phone bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Kategori</b> : <code><?php if($row->id_kategori == 0) {echo 'kelas masih kosong';} else {echo $row->nama_kategori;} ?></code></p>
                    </div>
                </li>
                <li style="margin-bottom:48px">
                    <i class="fa fa-chevron-circle-down bg-green"></i>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-book bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Nama Lengkap</b> : <?php echo $row->nama_lengkap; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-smile-o bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Gender</b> : <?php echo $row->gender; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-home bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Tempat, Tanggal Lahir</b> : <?php echo $row->tempat_lahir; ?> |
                            <?php 
                                $tgl = $row->tanggal_lahir;
                                $convert_tgl = strtotime($tgl);
                                $tgl = date('M d, Y', $convert_tgl);
                                echo $tgl;
                            ?>
                        </p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-road bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Alamat Lengkap</b> : <?php echo $row->alamat; ?>, <?php echo $row->kota; ?>, <?php echo $row->propinsi; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-foursquare bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Kode Pos</b> : <?php echo $row->kode_pos; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-phone bg-blue"></i>
                    <div class="timeline-item">
                        <p class="timeline-header no-border" style="font-size:14px"><span class="label_tag"><b>Telepon / Hp</b> : <?php echo $row->no_telepon; ?> | <?php echo $row->no_hp; ?></p>
                    </div>
                </li>
                <li style="margin-bottom:6px">
                    <i class="fa fa-times-circle bg-green"></i>
                </li>
            </ul>
        </div>
        <?php
            }
        ?>
    </div>
</dl>