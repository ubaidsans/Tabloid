<dl class="dl-horizontal">
    <div class="row">   
   
    </div>
</dl>