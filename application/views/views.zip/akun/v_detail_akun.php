<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hotel Apps | Manajemen Akun</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- masukin style ke view -->
    <?php $this->load->view('style/css.php'); ?>
</head>

<!-- header logo: style can be found in header.less -->

<?php $this->load->view('v_header.php'); ?>

<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">                
        <!-- sidebar: style can be found in sidebar.less -->
        <?php 
        $data['menuSelected'] = 'menu_akun';
        $this->load->view('v_left_menu.php', $data); 
        ?>
        <!-- /.sidebar -->
    </aside>

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">                
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <i class="fa fa-search" style="margin-right: 10px"></i>Detail Data Akun
                <small>Pusat Kendali</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>beranda/c_beranda/c_home"><i class="fa fa-dashboard"></i>Home</a></li>
                <li> <a href="<?php echo base_url(); ?>akun/c_m_akun"><i class="fa fa-users"></i>Manajemen Akun</a></li>
                <li class="active">Detail Akun</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <?php
            foreach ($detail->result() as $row) {
                ?>
                <h2 class="page-header">
                    <b><?php echo $row->nama_lengkap; ?></b> |
                    <?php 
                    if ($row->otoritas == 0) {
                        ?>
                        <span class="label label-info" style="font-size:12px; padding-top:4px; padding-bottom:4px"><?php echo "Member" ?></span>
                        <?php 
                    }
                    else {
                        ?>
                        <span class="label label-info" style="font-size:12px; padding-top:4px; padding-bottom:4px"><?php echo "Admin" ?></span>
                        <?php 
                    }
                    ?>
                    <?php 
                    if ($row->status == 'Aktif') {
                        ?>
                        <span class="label label-success" style="font-size:12px; padding-top:4px; padding-bottom:4px"><?php echo $row->status; ?></span>
                        <?php 
                    }
                    else {
                        ?>
                        <span class="label label-danger" style="font-size:12px; padding-top:4px; padding-bottom:4px"><?php echo $row->status; ?></span>
                        <?php 
                    }
                    ?>
                </h2>
                <div class="row">
                    <div class="col-md-12">
                        <!-- Custom Tabs -->
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#tab_1" data-toggle="tab">Data Akun</a></li>
                                <li><a href="#tab_2" data-toggle="tab">Data Profil</a></li>
                                <li><a href="#tab_3" data-toggle="tab">Catatan Aktivitas</a></li>
                                <li class="pull-right">
                                    <a href="<?php echo base_url(); ?>akun/c_m_akun/c_m_hapus_akun/<?php echo $row->id_user; ?>"><i class="fa fa-trash-o" title="Delete"></i></a>
                                </li>
                                <li class="pull-right" style="margin-right:-10px">
                                    <a href="javascript:$('#myModal .modal-content').load('<?php echo base_url(); ?>akun/c_m_akun/c_modal_edit_akun/dv/<?php echo $row->id_user; ?>',function(e){$('#myModal').modal('show');});"><i class="fa fa-edit" title="Update"></i></a>
                                </li>
                                <li class="pull-right" style="margin-right:-10px">
                                    <a href="<?php echo base_url(); ?>akun/c_m_akun"><i class="fa fa-arrow-circle-left" title="Back"></i></a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_1">
                                    <?php $this->load->view('akun/v_tab1_detail_akun'); ?>
                                </div><!-- /.tab-pane -->
                                <div class="tab-pane" id="tab_2">
                                    <?php $this->load->view('akun/v_tab2_detail_akun'); ?>
                                </div><!-- /.tab-pane -->
                                <div class="tab-pane" id="tab_3">
                                    <?php $this->load->view('akun/v_tab3_detail_akun'); ?>
                                </div><!-- /.tab-pane -->
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
            }
            ?>
        </section><!-- /.content -->
    </aside><!-- /.right-side -->

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:800px">
            <div class="modal-content" >            

            </div>
        </div>
    </div>
</div><!-- ./wrapper -->

<?php $this->load->view('v_footer');?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="<?php echo base_url(); ?>assets/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/js/AdminLTE/app.js" type="text/javascript"></script>
<!-- page script -->
<script type="text/javascript">
    $(function() {
        $("#tabel_1").dataTable();
        $("#tabel_2").dataTable();
    });
</script>        
</body>
</html>