<div id="footer" class="col-lg-12">
    <div class="col-md-1">
        <a href="http://ptiik.ub.ac.id/"><img src="<?php echo base_url(); ?>assets/img/logo/ptiik.png" style="width:100px" ></a>
    </div>
    <div class="col-md-11">
        <p class="pull-right"><i class="fa fa-foursquare"></i>&nbsp;Gunakan browser <strong style="color:red">Goggle Chrome</strong> untuk tampilan dan performa maksimal.&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" class="btn btn-default btn-sm btn-backtop"><i class="glyphicon glyphicon-circle-arrow-up"></i>&nbsp;&nbsp;Back to top</a></p>

        <p style="font-size:13px">
            <strong>IPTV Backoffice v.1.0</strong> dibangun dengan <a href="http://getbootstrap.com/">Bootstrap 3</a> | <a href="http://almsaeedstudio.com/">Admin LTE</a> | <a href="http://ellislab.com/codeigniter" target="_blank">Code Igniter v.2.2.0</a><br>
            Copyright &copy; <?php echo date("Y"); ?> <a href="http://ptiik.ub.ac.id/labpapb/">Lab. PAPB PTIIK UB</a>
        </p>
    </div>
</div>